﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DAL.DBconnect;

namespace DAL
{
    public class DinhDuong_DAL
    {
        DBconnect dah = new DBconnect();
        public DataTable getDD()
        {
            string s = "SELECT * FROM tblDinhDuong";
            return dah.get_DaTaTable(s);
        }
        public DataTable getMaDD()
        {
            string s = "SELECT MaDD FROM tblDinhDuong ";
            return dah.get_DaTaTable(s );
        }
        public void ThemDD(DinhDuong_DTO dinhduong)
        {
            string s = ("insert into  tblDinhDuong values (N'" + dinhduong.MaDD + "',N'" + dinhduong.TenDD + "')");
            dah.RunSQL(s);
        }
        public void XoaDD(DinhDuong_DTO dinhduong)
        {

            string s = ("DELETE FROM tblDinhDuong where MaDD= N'" + dinhduong.MaDD + "'");
            dah.RunSQL(s);

        }
        public bool editDD(DinhDuong_DTO dinhduong)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            try
            {
                conn.Open();
                string SQL = string.Format("UPDATE tblDinhDuong SET TenDD = '{0}' WHERE MaDD = '{1}'", dinhduong.TenDD, dinhduong.MaDD);
                //                string SQL = string.Format("UPDATE MON SET TenMon = '{0}', NhomMon = '{1}', Gia = '{2}', DonVi = '{3}' WHERE IDMon = '{4}'", food.FoodName, food.FoodType, food.FoodPrices, food.FoodUnit, food.FoodID);
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            return false;
        }
    }
}
