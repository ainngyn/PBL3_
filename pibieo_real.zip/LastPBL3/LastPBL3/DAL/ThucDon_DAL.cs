﻿using DTO;

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DAL
{
    public class ThucDon_DAL : DBconnect
    {
        DBconnect dah = new DBconnect();
        public DataTable getMA()
        {
            string s = "SELECT * FROM tblMonAn";
            return dah.get_DaTaTable(s);
        }
        public void getcbMA()
        {
            string s = "SELECT TenMA, DonGia, MaMA FROM tblMonAn";
            dah.thucthi(s);
        }

        public void themMA(ThucDon_DTO thucdon)
        {
            
            string s = ("insert into  tblMonAn values (N'" + thucdon.MaMA + "',N'" + thucdon.TenMA + "','" + thucdon.Calo + "','" + thucdon.DonGia + "',N'" + thucdon.FK_MaDD + "',N'" + thucdon.FK_MaDM + "')");
            dah.RunSQL(s);
           

        }
        public bool editMA(ThucDon_DTO thucdon)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            try
            {
                conn.Open();
                string SQL = string.Format("UPDATE tblMonAn SET TenMA = '{0}', Calo ='{1}', DonGia ='{2}', FK_MaDD = '{3}', FK_MaDM ='{4}' WHERE MaMA = '{5}'", thucdon.TenMA, thucdon.Calo, thucdon.DonGia, thucdon.FK_MaDD, thucdon.FK_MaDM, thucdon.MaMA);
//                string SQL = string.Format("UPDATE MON SET TenMon = '{0}', NhomMon = '{1}', Gia = '{2}', DonVi = '{3}' WHERE IDMon = '{4}'", food.FoodName, food.FoodType, food.FoodPrices, food.FoodUnit, food.FoodID);
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            return false;
        }

        public void Xoa(ThucDon_DTO thucdon)
        {
            string s = ("DELETE FROM tblMonAn where MaMA = N'" + thucdon.MaMA + "'");
            dah.RunSQL(s);
        }
        public DataTable getTimMA(string s)
        {
            return dah.get_DaTaTable(s);
        }

        
        
        
        public string getMaMA(string tenma)
        {
            string ids = null;
            SqlConnection conn = SqlConnectionData.Connect();
            conn.Open();
            string data = string.Format("SELECT * FROM tblMonAn WHERE TenMA = '{0}'", tenma);
            SqlDataAdapter da = new SqlDataAdapter(data, conn);
            DataTable dtMA = new DataTable();
            da.Fill(dtMA);
            conn.Close();
            foreach (DataRow row in dtMA.Rows)
            {
                ids = row["MaMA"].ToString();
            }
            conn.Close();
            return ids;
        }
     
       
        public string getDonGia(string dongia)
        {
            string ids = null;
            SqlConnection conn = SqlConnectionData.Connect();
            conn.Open();
            string data = string.Format("SELECT * FROM tblMonAn WHERE TenMA = '{0}'", dongia);
            SqlDataAdapter da = new SqlDataAdapter(data, conn);
            DataTable dtMA = new DataTable();
            da.Fill(dtMA);
            conn.Close();
            foreach (DataRow row in dtMA.Rows)
            {
                ids = row["DonGia"].ToString();
            }
            conn.Close();
            return ids;
        }
        public string getTenMA(string tenma)
        {
            string ids = null;
            SqlConnection conn = SqlConnectionData.Connect();
            conn.Open();
            string data = string.Format("SELECT * FROM tblMonAn WHERE TenMA = '{0}'", tenma);
            SqlDataAdapter da = new SqlDataAdapter(data, conn);
            DataTable dtMA = new DataTable();
            da.Fill(dtMA);
            conn.Close();
            foreach (DataRow row in dtMA.Rows)
            {
                ids = row["TenMA"].ToString();
            }
            conn.Close();
            return ids;
        }
      
        public DataTable ListTK(string tenma)
        {
          
            string s = "SELECT * FROM tblMonAn WHERE TenMA LIKE N'%" + tenma + "%'";
            return dah.get_DaTaTable(s);
        }
        public int DemBanGhi(string mama)
        {
            int banghi;
            banghi = dah.TongBanGhi("SELECT * FROM tblMonAn WHERE MaMA ='" + mama + "' ");
            return banghi;
        }
      


    }
}
