﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DAL.DBconnect;

namespace DAL
{
    public class DanhMuc_DAL
    {
        DBconnect dah = new DBconnect();
        public DataTable getDM()
        {
            string s = "SELECT * FROM tblDanhMuc";
           return dah.get_DaTaTable(s);
        }
        public DataTable getMaDM()
        {
            string s = "SELECT MaDM FROM tblDanhMuc";
            return dah.get_DaTaTable(s);
        }
        public void ThemDM(DanhMuc_DTO danhmuc)
        {
            string s = ("insert into  tblDanhMuc values (N'" + danhmuc.MaDM + "',N'" + danhmuc.TenDM + "')");
            dah.RunSQL(s);
        }
        public void XoaDM(DanhMuc_DTO danhmuc)
        {
           
                string s = ("DELETE FROM tblDanhMuc where MaDM = N'" + danhmuc.MaDM + "'");
                dah.RunSQL(s);
            
        }
        public bool editDM(DanhMuc_DTO danhmuc)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            try
            {
                conn.Open();
           //     string SQL = string.Format("UPDATE tblDanhMuc SET TenDM =N'" + danhmuc.TenDM + "',MaDM =N'" + danhmuc.MaDM+"'");
                string SQL = string.Format("UPDATE tblDanhMuc SET TenDM = '{0}' WHERE MaDM = '{1}'", danhmuc.TenDM, danhmuc.MaDM);
                //                string SQL = string.Format("UPDATE MON SET TenMon = '{0}', NhomMon = '{1}', Gia = '{2}', DonVi = '{3}' WHERE IDMon = '{4}'", food.FoodName, food.FoodType, food.FoodPrices, food.FoodUnit, food.FoodID);
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }    
                  
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            return false;
        }

    }
}
