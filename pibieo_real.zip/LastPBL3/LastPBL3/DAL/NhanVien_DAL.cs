﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DAL.DBconnect;
namespace DAL
{
    public class NhanVien_DAL
    {
        DBconnect dah = new DBconnect();
        public DataTable getNV()
        {
            string s = "SELECT * FROM tblNhanVien";
            return dah.get_DaTaTable(s);
        }
        public void ThemNV(NhanVien_DTO nhanvien)
        {
            string s = ("insert into  tblNhanVien values (N'" + nhanvien.MaNV + "',N'" + nhanvien.TenNV + "',N'"+ nhanvien.GioiTinh+ "',N'"+nhanvien.DiaChi+ "',N'"+nhanvien.DienThoai+ "',N'"+nhanvien.FK_MaTK+ "')");
            dah.RunSQL(s);
        }
        public void XoaNV(NhanVien_DTO nhanvien)
        {

            string s = ("DELETE FROM tblNhanVien where MaNV= N'" + nhanvien.MaNV + "'");
            dah.RunSQL(s);

        }
        public bool editNV(NhanVien_DTO nhanvien)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            try
            {
                conn.Open();
                string SQL = string.Format("UPDATE tblNhanVien SET TenNV = '{0}', GioiTinh = '{1}',DiaChi='{2}',DienThoai='{3}',FK_MaTK='{4}' WHERE MaNV = '{5}'", nhanvien.TenNV, nhanvien.GioiTinh, nhanvien.DiaChi,nhanvien.DienThoai,nhanvien.FK_MaTK,nhanvien.MaNV);
                //                string SQL = string.Format("UPDATE MON SET TenMon = '{0}', NhomMon = '{1}', Gia = '{2}', DonVi = '{3}' WHERE IDMon = '{4}'", food.FoodName, food.FoodType, food.FoodPrices, food.FoodUnit, food.FoodID);
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            return false;
        }
    }
}
