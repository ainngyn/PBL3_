﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
namespace BLL
{
    public class ChiTietHD_BLL
    {
       
        ChiTietHD_DAL chitiethddal = new ChiTietHD_DAL();
        DBconnect dah =new DBconnect();

        public DataTable Loadcthd()
        {
            return chitiethddal.LoadCTHD();
        }
        public DataTable getCTHD(string idh)
        {
            return chitiethddal.getCTHD(idh);
        }
     
        public DataTable getTenMA()
        {
            return chitiethddal.getTenMA();
        }
      
        
        public void insertCTHD(string mahd, string mama, int soluong,int dongia, int thanhtien)
        {
            chitiethddal.insertCTHD(new ChiTietHD_DTO(mahd, mama, soluong, dongia, thanhtien));
          
        }
        public DataTable Listcthd(string mahd)
        {
            return chitiethddal.List1(mahd);

        }
        public void XoaCTHD(string mahd, string mama, int soluong, int  dongia, int thanhtien)
        {
            chitiethddal.XoaCTHD(new ChiTietHD_DTO(mahd, mama, soluong, dongia, thanhtien));
        }
        public DataTable ThongKeSanPhamBanChay()
        {
            return chitiethddal.ThongKeHangBanChay();
        }
        public DataTable ThongKeSanPhamBanCham()
        {
            return chitiethddal.ThongKeHangBanCham();
        }
       
        public int tongbanghi(string mahd, string tenma)
        {
            return chitiethddal.DemBanGhi(mahd, tenma);
        }

    }
}
