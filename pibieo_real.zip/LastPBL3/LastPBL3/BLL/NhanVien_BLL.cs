﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;

namespace BLL
{
    public class NhanVien_BLL
    {
        NhanVien_DAL nhanviendal = new NhanVien_DAL();
        public DataTable getNV()
        {
            return nhanviendal.getNV();
        }
        public void ThemNV(string manv, string tennv, string gioitinh, string diachi, string dienthoai, string matk)
        {
          
            nhanviendal.ThemNV(new NhanVien_DTO(manv, tennv,gioitinh, diachi,dienthoai,matk));
        }
        public void XoaNV(string manv, string tennv, string gioitinh, string diachi, string dienthoai, string matk)
        {
            nhanviendal.XoaNV(new NhanVien_DTO(manv, tennv,gioitinh, diachi, dienthoai,matk));
        }
        public bool editNV(NhanVien_DTO nhanvien)
        {
            return nhanviendal.editNV(nhanvien);
        }
    }
}
