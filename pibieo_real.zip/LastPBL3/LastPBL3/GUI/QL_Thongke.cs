﻿using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class QL_Thongke : UserControl
    {
        public QL_Thongke()
        {
            InitializeComponent();
        }
        ChiTietHD_BLL cthdbll = new ChiTietHD_BLL();

        private void dgThongKesp_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbTKHD_Click(object sender, EventArgs e)
        {

        }

        private void QL_Thongke_Load(object sender, EventArgs e)
        {
            dgThongKesp.DataSource = cthdbll.Loadcthd();
        }

        private void tsThongKe_Click(object sender, EventArgs e)
        {
            if (cbKieuThongKe.Text == "Thống kê sản phẩm bán chạy")
            {
                dgThongKesp.DataSource = cthdbll.ThongKeSanPhamBanChay();

            }

            else if (cbKieuThongKe.Text == "Thống kê sản phẩm bán chậm")
            {
                dgThongKesp.DataSource = cthdbll.ThongKeSanPhamBanCham();

            }

            else
                MessageBox.Show("Bạn phải nhập kiêu thống kê");
        }

        private void cbKieuThongKe_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tsLamMoi_Click(object sender, EventArgs e)
        {
            cbKieuThongKe.Text = "";
            dgThongKesp.ClearSelection();
        }
    }
}
