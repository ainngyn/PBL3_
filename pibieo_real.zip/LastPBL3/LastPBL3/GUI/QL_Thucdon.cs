﻿using BLL;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class QL_Thucdon : UserControl
    {
        ThucDon_BLL thucdonbll = new ThucDon_BLL();
        DinhDuong_BLL ddbll = new DinhDuong_BLL();
        DanhMuc_BLL dmbll = new DanhMuc_BLL();
       
        public QL_Thucdon()
        {
            InitializeComponent();
        }
        private void btThemMA_Click(object sender, EventArgs e)
        {
            if (txtMaMA.Text != "" && txtTenMA.Text != "" && txtCalo.Text != "" && txtDonGia.Text != "" && cbDD.Text!=""&& cbDM.Text !="")
            {
                thucdonbll.themma(txtMaMA.Text, (txtTenMA.Text), Int32.Parse(txtCalo.Text),Int32.Parse(txtDonGia.Text),cbDD.Text,cbDM.Text);
                MessageBox.Show("Add completed!");
                QL_Thucdon_Load(sender, e);
                ResetValue();

            }
            else
                    {
                        MessageBox.Show("Thêm Thất Bại,Bạn Phải Nhập Đầy Đủ Thông Tin", "Cảnh Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    }



        }
       

        private void QL_Thucdon_Load(object sender, EventArgs e)
        {
            cbDD.DataSource = ddbll.getMaDD();
            cbDD.DisplayMember = "MaDD";

           // cbDD.DataSource = thucdonbll.getMaDD();
            cbDM.DataSource = dmbll.getMaDM();
            cbDM.DisplayMember = "MaDM";
            dgvMA.DataSource = thucdonbll.getMA();
        }
        

        private void ResetValue()
        {
            txtMaMA.Clear();
            txtTenMA.Clear();
            txtCalo.Clear();
            txtDonGia.Clear();
            cbDD.Text = "";
            cbDM.Text = "";
        }

        private void btResetMA_Click_1(object sender, EventArgs e)
        {
            ResetValue();
            
        }

      

        private void btXoaMA_Click(object sender, EventArgs e)
        {
            DialogResult q = MessageBox.Show("Bạn Có Muốn Xóa Sản Phẩm Này Không?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (q.Equals(DialogResult.Yes))
            {
                
                
                    thucdonbll.XoaSP(txtMaMA.Text, txtTenMA.Text, Int32.Parse(txtCalo.Text), Int32.Parse(txtDonGia.Text), cbDD.Text, cbDM.Text);
                    QL_Thucdon_Load(sender, e);
                
            }
        }

        private void btSuaMA_Click(object sender, EventArgs e)
        {
            if (dgvMA.SelectedRows.Count > 0)
            {
                if (txtMaMA.Text != "" && txtTenMA.Text != "" && txtCalo.Text != "" && txtDonGia.Text != "" && cbDD.Text != "" && cbDM.Text !="")
                {
                    string calo1 = txtCalo.Text;
                    int calo = Convert.ToInt32(calo1, CultureInfo.InvariantCulture);
                    string gia1 = txtDonGia.Text;
                    int gia = Convert.ToInt32(gia1, CultureInfo.InvariantCulture);
                    ThucDon_DTO thucdon = new ThucDon_DTO(txtMaMA.Text,txtTenMA.Text,calo,gia,cbDD.Text,cbDM.Text);
                   

                    if (thucdonbll.editMA(thucdon))
                    {
                        MessageBox.Show("Edit Completed!!");
                        dgvMA.DataSource = thucdonbll.getMA();
                       
                    }
                    else
                    {
                        MessageBox.Show("Edit failed");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter in full");
                }
            }




        }
     


        private void txtMaMA_TextChanged(object sender, EventArgs e)
        {

        }
    
        private void cbDD_SelectedIndexChanged(object sender, EventArgs e)
        {
              
        }

        private void dgvMA_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvMA_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow;
            numrow = e.RowIndex;
            txtMaMA.Text= dgvMA.Rows[numrow].Cells[0].Value.ToString();
            txtTenMA.Text = dgvMA.Rows[numrow].Cells[1].Value.ToString();
            txtCalo.Text = dgvMA.Rows[numrow].Cells[2].Value.ToString();
            txtDonGia.Text = dgvMA.Rows[numrow].Cells[3].Value.ToString();
            cbDD.Text = dgvMA.Rows[numrow].Cells[4].Value.ToString();
            cbDM.Text = dgvMA.Rows[numrow].Cells[5].Value.ToString();   
        }

        private void dgvMA_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbDD_DataSourceChanged(object sender, EventArgs e)
        {

        }

        private void cbDD_ValueMemberChanged(object sender, EventArgs e)
        {

        }

        private void cbDM_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tblMonAnBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }


        private void btTimMA_Click(object sender, EventArgs e)
        {
            dgvMA.DataSource = thucdonbll.ListTK(txtTimMA.Text);
            txtTimMA.Text = "";

        }
        public void XemMA()
        {
            dgvMA.DataSource = thucdonbll.getMA();
        }
        private void btXemMA_Click(object sender, EventArgs e)
        {
            XemMA();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

