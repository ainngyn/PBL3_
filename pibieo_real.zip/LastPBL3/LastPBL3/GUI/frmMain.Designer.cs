﻿namespace GUI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.gunaLinePanel1 = new Guna.UI.WinForms.GunaLinePanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUser = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.panelControl = new System.Windows.Forms.Panel();
            this.gunaControlBox1 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaGradientPanel1 = new Guna.UI.WinForms.GunaGradientPanel();
            this.btNhanVien = new Guna.UI.WinForms.GunaButton();
            this.btDangXuat = new Guna.UI.WinForms.GunaButton();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.btThongKe = new Guna.UI.WinForms.GunaButton();
            this.btHoaDon = new Guna.UI.WinForms.GunaButton();
            this.btDanhMuc = new Guna.UI.WinForms.GunaButton();
            this.btThucDon = new Guna.UI.WinForms.GunaButton();
            this.gunaLinePanel1.SuspendLayout();
            this.gunaGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaLinePanel1
            // 
            this.gunaLinePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gunaLinePanel1.Controls.Add(this.label1);
            this.gunaLinePanel1.Controls.Add(this.txtUser);
            this.gunaLinePanel1.LineColor = System.Drawing.Color.Black;
            this.gunaLinePanel1.LineStyle = System.Windows.Forms.BorderStyle.None;
            this.gunaLinePanel1.Location = new System.Drawing.Point(268, 74);
            this.gunaLinePanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gunaLinePanel1.Name = "gunaLinePanel1";
            this.gunaLinePanel1.Size = new System.Drawing.Size(1418, 121);
            this.gunaLinePanel1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1065, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome";
            // 
            // txtUser
            // 
            this.txtUser.BaseColor = System.Drawing.Color.White;
            this.txtUser.BorderColor = System.Drawing.Color.Silver;
            this.txtUser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtUser.FocusedBaseColor = System.Drawing.Color.White;
            this.txtUser.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtUser.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtUser.Font = new System.Drawing.Font("Segoe UI Black", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUser.Location = new System.Drawing.Point(1192, 66);
            this.txtUser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtUser.Name = "txtUser";
            this.txtUser.PasswordChar = '\0';
            this.txtUser.SelectedText = "";
            this.txtUser.Size = new System.Drawing.Size(208, 52);
            this.txtUser.TabIndex = 0;
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(291, 20);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(406, 38);
            this.gunaLabel1.TabIndex = 1;
            this.gunaLabel1.Text = "TIỆM CƠM VĂN PHÒNG";
            // 
            // panelControl
            // 
            this.panelControl.BackgroundImage = global::GUI.Properties.Resources.hinh_do_an_cute;
            this.panelControl.Location = new System.Drawing.Point(268, 194);
            this.panelControl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelControl.Name = "panelControl";
            this.panelControl.Size = new System.Drawing.Size(1418, 749);
            this.panelControl.TabIndex = 10;
            this.panelControl.Paint += new System.Windows.Forms.PaintEventHandler(this.panelControl_Paint);
            // 
            // gunaControlBox1
            // 
            this.gunaControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox1.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox1.AnimationSpeed = 0.03F;
            this.gunaControlBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gunaControlBox1.BackgroundImage = global::GUI.Properties.Resources._500px_Crystal_Clear_action_exit_svg;
            this.gunaControlBox1.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox1.IconSize = 15F;
            this.gunaControlBox1.Location = new System.Drawing.Point(1596, -5);
            this.gunaControlBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gunaControlBox1.Name = "gunaControlBox1";
            this.gunaControlBox1.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.gunaControlBox1.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox1.Size = new System.Drawing.Size(89, 80);
            this.gunaControlBox1.TabIndex = 2;
            // 
            // gunaGradientPanel1
            // 
            this.gunaGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gunaGradientPanel1.BackgroundImage")));
            this.gunaGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gunaGradientPanel1.Controls.Add(this.btNhanVien);
            this.gunaGradientPanel1.Controls.Add(this.btDangXuat);
            this.gunaGradientPanel1.Controls.Add(this.gunaPictureBox1);
            this.gunaGradientPanel1.Controls.Add(this.btThongKe);
            this.gunaGradientPanel1.Controls.Add(this.btHoaDon);
            this.gunaGradientPanel1.Controls.Add(this.btDanhMuc);
            this.gunaGradientPanel1.Controls.Add(this.btThucDon);
            this.gunaGradientPanel1.GradientColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gunaGradientPanel1.GradientColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gunaGradientPanel1.GradientColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gunaGradientPanel1.GradientColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gunaGradientPanel1.Location = new System.Drawing.Point(1, -5);
            this.gunaGradientPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gunaGradientPanel1.Name = "gunaGradientPanel1";
            this.gunaGradientPanel1.Size = new System.Drawing.Size(268, 948);
            this.gunaGradientPanel1.TabIndex = 8;
            this.gunaGradientPanel1.Text = "gunaGradientPanel1";
            // 
            // btNhanVien
            // 
            this.btNhanVien.AnimationHoverSpeed = 0.07F;
            this.btNhanVien.AnimationSpeed = 0.03F;
            this.btNhanVien.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btNhanVien.BorderColor = System.Drawing.Color.Black;
            this.btNhanVien.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btNhanVien.FocusedColor = System.Drawing.Color.Empty;
            this.btNhanVien.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNhanVien.ForeColor = System.Drawing.Color.Black;
            this.btNhanVien.Image = ((System.Drawing.Image)(resources.GetObject("btNhanVien.Image")));
            this.btNhanVien.ImageSize = new System.Drawing.Size(20, 20);
            this.btNhanVien.Location = new System.Drawing.Point(0, 658);
            this.btNhanVien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btNhanVien.Name = "btNhanVien";
            this.btNhanVien.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btNhanVien.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btNhanVien.OnHoverForeColor = System.Drawing.Color.White;
            this.btNhanVien.OnHoverImage = null;
            this.btNhanVien.OnPressedColor = System.Drawing.Color.Black;
            this.btNhanVien.Size = new System.Drawing.Size(268, 86);
            this.btNhanVien.TabIndex = 15;
            this.btNhanVien.Text = "Nhân viên";
            this.btNhanVien.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btNhanVien.Click += new System.EventHandler(this.btNhanVien_Click);
            // 
            // btDangXuat
            // 
            this.btDangXuat.AnimationHoverSpeed = 0.07F;
            this.btDangXuat.AnimationSpeed = 0.03F;
            this.btDangXuat.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btDangXuat.BorderColor = System.Drawing.Color.Black;
            this.btDangXuat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btDangXuat.FocusedColor = System.Drawing.Color.Empty;
            this.btDangXuat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDangXuat.ForeColor = System.Drawing.Color.Black;
            this.btDangXuat.Image = ((System.Drawing.Image)(resources.GetObject("btDangXuat.Image")));
            this.btDangXuat.ImageSize = new System.Drawing.Size(20, 20);
            this.btDangXuat.Location = new System.Drawing.Point(0, 768);
            this.btDangXuat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btDangXuat.Name = "btDangXuat";
            this.btDangXuat.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btDangXuat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btDangXuat.OnHoverForeColor = System.Drawing.Color.White;
            this.btDangXuat.OnHoverImage = null;
            this.btDangXuat.OnPressedColor = System.Drawing.Color.Black;
            this.btDangXuat.Size = new System.Drawing.Size(268, 86);
            this.btDangXuat.TabIndex = 14;
            this.btDangXuat.Text = "Đăng xuất";
            this.btDangXuat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btDangXuat.Click += new System.EventHandler(this.btDangXuat_Click);
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::GUI.Properties.Resources.pngegg__1_;
            this.gunaPictureBox1.Location = new System.Drawing.Point(0, 0);
            this.gunaPictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(268, 200);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 7;
            this.gunaPictureBox1.TabStop = false;
            // 
            // btThongKe
            // 
            this.btThongKe.AnimationHoverSpeed = 0.07F;
            this.btThongKe.AnimationSpeed = 0.03F;
            this.btThongKe.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btThongKe.BorderColor = System.Drawing.Color.Black;
            this.btThongKe.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btThongKe.FocusedColor = System.Drawing.Color.Empty;
            this.btThongKe.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThongKe.ForeColor = System.Drawing.Color.Black;
            this.btThongKe.Image = ((System.Drawing.Image)(resources.GetObject("btThongKe.Image")));
            this.btThongKe.ImageSize = new System.Drawing.Size(20, 20);
            this.btThongKe.Location = new System.Drawing.Point(-3, 552);
            this.btThongKe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btThongKe.Name = "btThongKe";
            this.btThongKe.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btThongKe.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btThongKe.OnHoverForeColor = System.Drawing.Color.White;
            this.btThongKe.OnHoverImage = null;
            this.btThongKe.OnPressedColor = System.Drawing.Color.Black;
            this.btThongKe.Size = new System.Drawing.Size(268, 86);
            this.btThongKe.TabIndex = 10;
            this.btThongKe.Text = "Thống kê";
            this.btThongKe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btThongKe.Click += new System.EventHandler(this.btThongKe_Click);
            // 
            // btHoaDon
            // 
            this.btHoaDon.AnimationHoverSpeed = 0.07F;
            this.btHoaDon.AnimationSpeed = 0.03F;
            this.btHoaDon.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btHoaDon.BorderColor = System.Drawing.Color.Black;
            this.btHoaDon.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btHoaDon.FocusedColor = System.Drawing.Color.Empty;
            this.btHoaDon.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHoaDon.ForeColor = System.Drawing.Color.Black;
            this.btHoaDon.Image = ((System.Drawing.Image)(resources.GetObject("btHoaDon.Image")));
            this.btHoaDon.ImageSize = new System.Drawing.Size(20, 20);
            this.btHoaDon.Location = new System.Drawing.Point(-3, 439);
            this.btHoaDon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btHoaDon.Name = "btHoaDon";
            this.btHoaDon.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btHoaDon.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btHoaDon.OnHoverForeColor = System.Drawing.Color.White;
            this.btHoaDon.OnHoverImage = null;
            this.btHoaDon.OnPressedColor = System.Drawing.Color.Black;
            this.btHoaDon.Size = new System.Drawing.Size(268, 86);
            this.btHoaDon.TabIndex = 11;
            this.btHoaDon.Text = "Hóa đơn";
            this.btHoaDon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btHoaDon.Click += new System.EventHandler(this.btHoaDon_Click);
            // 
            // btDanhMuc
            // 
            this.btDanhMuc.AnimationHoverSpeed = 0.07F;
            this.btDanhMuc.AnimationSpeed = 0.03F;
            this.btDanhMuc.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btDanhMuc.BorderColor = System.Drawing.Color.Black;
            this.btDanhMuc.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btDanhMuc.FocusedColor = System.Drawing.Color.Empty;
            this.btDanhMuc.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDanhMuc.ForeColor = System.Drawing.Color.Black;
            this.btDanhMuc.Image = ((System.Drawing.Image)(resources.GetObject("btDanhMuc.Image")));
            this.btDanhMuc.ImageSize = new System.Drawing.Size(20, 20);
            this.btDanhMuc.Location = new System.Drawing.Point(0, 331);
            this.btDanhMuc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btDanhMuc.Name = "btDanhMuc";
            this.btDanhMuc.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btDanhMuc.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btDanhMuc.OnHoverForeColor = System.Drawing.Color.White;
            this.btDanhMuc.OnHoverImage = null;
            this.btDanhMuc.OnPressedColor = System.Drawing.Color.Black;
            this.btDanhMuc.Size = new System.Drawing.Size(268, 86);
            this.btDanhMuc.TabIndex = 10;
            this.btDanhMuc.Text = "Danh mục";
            this.btDanhMuc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btDanhMuc.Click += new System.EventHandler(this.btDanhMuc_Click);
            // 
            // btThucDon
            // 
            this.btThucDon.AnimationHoverSpeed = 0.07F;
            this.btThucDon.AnimationSpeed = 0.03F;
            this.btThucDon.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btThucDon.BorderColor = System.Drawing.Color.Black;
            this.btThucDon.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btThucDon.FocusedColor = System.Drawing.Color.Empty;
            this.btThucDon.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThucDon.ForeColor = System.Drawing.Color.Black;
            this.btThucDon.Image = ((System.Drawing.Image)(resources.GetObject("btThucDon.Image")));
            this.btThucDon.ImageSize = new System.Drawing.Size(20, 20);
            this.btThucDon.Location = new System.Drawing.Point(0, 237);
            this.btThucDon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btThucDon.Name = "btThucDon";
            this.btThucDon.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btThucDon.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btThucDon.OnHoverForeColor = System.Drawing.Color.White;
            this.btThucDon.OnHoverImage = null;
            this.btThucDon.OnPressedColor = System.Drawing.Color.Black;
            this.btThucDon.Size = new System.Drawing.Size(268, 86);
            this.btThucDon.TabIndex = 9;
            this.btThucDon.Text = "Thực đơn";
            this.btThucDon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btThucDon.Click += new System.EventHandler(this.btThucDon_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1682, 948);
            this.Controls.Add(this.gunaLabel1);
            this.Controls.Add(this.gunaControlBox1);
            this.Controls.Add(this.panelControl);
            this.Controls.Add(this.gunaLinePanel1);
            this.Controls.Add(this.gunaGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cơm ngon văn phòng";
            this.gunaLinePanel1.ResumeLayout(false);
            this.gunaLinePanel1.PerformLayout();
            this.gunaGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaGradientPanel gunaGradientPanel1;
        private Guna.UI.WinForms.GunaButton btThucDon;
        private Guna.UI.WinForms.GunaButton btThongKe;
        private Guna.UI.WinForms.GunaButton btHoaDon;
        private Guna.UI.WinForms.GunaButton btDanhMuc;
        private Guna.UI.WinForms.GunaButton btDangXuat;
        private Guna.UI.WinForms.GunaLinePanel gunaLinePanel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaTextBox txtUser;
        private System.Windows.Forms.Panel panelControl;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox1;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaButton btNhanVien;
    }
}