﻿using BLL;
using DTO;
using Guna.UI.Licensing;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using COMExcel = Microsoft.Office.Interop.Excel;

namespace GUI
{
    public partial class QL_Hoadon : UserControl
    {
        public static bool isVegetarian;
        public static int targetCalories;
        public static int bestPrice;
        HoaDon_BLL hoadonbll = new HoaDon_BLL();
        ThucDon_BLL tdbll = new ThucDon_BLL();  
        NhanVien_BLL nvnll = new NhanVien_BLL();
        ChiTietHD_BLL cthdbll = new ChiTietHD_BLL();
        DataTable dt = new DataTable();
        public QL_Hoadon()
        {
            InitializeComponent();
        }
        public void getMama()
        {
            cbMaMA.DataSource = cthdbll.getTenMA();
            cbMaMA.DisplayMember = "TenMA";
        }
        public void getMaNV()
        {
            cbMaNV.DataSource = nvnll.getNV();
            cbMaNV.DisplayMember = "MaNV";
          
        }
        

        private void btThemHD_Click(object sender, EventArgs e)
        {
            try
            {
                //Kiểm tra mã có trùng hay không?
                if (hoadonbll.tongbanghi(txtMaHD.Text) == 1)
                    MessageBox.Show("Mã: " + txtMaHD.Text + " đã tồn tại. Nhập mã khác!");
                else if (hoadonbll.tongbanghi(txtMaHD.Text) == 0)
                {

                    if (txtMaHD.Text != "" && cbMaNV.Text != "" &&  dtpNgayBan.Text != "")
                    {
                        hoadonbll.Themhd(txtMaHD.Text, cbMaNV.Text,Int32.Parse(txtTongTien.Text));
                        MessageBox.Show("them thanh cong");
                        QL_Hoadon_Load_1(sender, e);
                    }


                }
            }
            catch
            {
                MessageBox.Show("Thêm thất bại", "thôngbao", MessageBoxButtons.OK);
            }
        }


        private void QL_Hoadon_Load_1(object sender, EventArgs e)
        {
            // load hóa đơn
            dgvHD.DataSource = hoadonbll.getHD();
            dgvHD.Columns["MaHD"].HeaderText = "Mã Hóa đơn";
            dgvHD.Columns["NgayBan"].HeaderText = "Ngày bán";
            dgvHD.Columns["MaNV"].HeaderText = "Mã nhân viên";
            dgvHD.Columns["TongTien"].HeaderText = "Tổng tiền";


            dgvCTHD.DataSource = cthdbll.Listcthd(txtMaHD.Text);
            dgvCTHD.Columns["MaHD"].HeaderText = "Mã HD";
            dgvCTHD.Columns["TenMA"].HeaderText = "Tên MA";
            dgvCTHD.Columns["SoLuong"].HeaderText = "Số lượng";
            dgvCTHD.Columns["DonGia"].HeaderText = "Đơn giá";
            dgvCTHD.Columns["ThanhTien"].HeaderText = "Thành tiền";
            
            //load ma nhan vien
            cbMaNV.DataSource = nvnll.getNV();
            cbMaNV.DisplayMember = "MaNV";
            //// load ngay bán là ngày hiện tại
            dtpNgayBan.Text = DateTime.Today.ToShortDateString();
            // Load tên ma và đơn giá
              cbMaMA.DataSource = tdbll.getMA();
         //   cbMaMA.DataSource = tdbll.getcbMA();
            cbMaMA.DisplayMember = "TenMA";
            cbMaMA.ValueMember = "DonGia";

            txtTongTien.Text = "0";
            txtDonGia.Text = "";
            cbMaNV.Text = "";// moi them vo
            cbMaMA.Text = "";

        }

        private void btHuyHD_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn xóa phiếu xuất này không?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                hoadonbll.Xoahd(txtMaHD.Text, cbMaNV.Text, Int32.Parse(txtTongTien.Text));
                MessageBox.Show("xoa thanh cong");
                QL_Hoadon_Load_1(sender, e);
            }
        }

        private void cbMaMA_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDonGia.Text = cbMaMA.SelectedValue.ToString();
            
        }


        private void txtSoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar)&& !char.IsControl(e.KeyChar))
            {
                MessageBox.Show("Chỉ được nhập kí tự số");
                e.Handled = true;
            }
            tinhtien();
           
        }

        private void txtDonGia_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("Chỉ được nhập kí tự số");
            e.Handled = true;
        }
        public void tinhtien()
        {
            int soluong;
            int dongia, thanhtien;
            if (txtSoLuong.Text == "")
            { MessageBox.Show("chua nhap so luong"); }
            else
            {
                soluong = int.Parse(txtSoLuong.Text);
                dongia = int.Parse(txtDonGia.Text);

                if (soluong <= 0)
                {
                    MessageBox.Show("so luong phai >0");
                }
                else
                {
                    thanhtien = soluong * dongia;
                    txtThanhTien.Text = thanhtien.ToString();

                }

            }
        }
      
        private void btThemM_Click(object sender, EventArgs e)
        {
            
            if (cthdbll.tongbanghi(txtMaCTHD.Text, cbMaMA.Text) == 1)
            {
                MessageBox.Show("Chi tiết phiếu xuất này không hợp lệ. Nhập chi tiết phiếu xuất khác!");
            }    
                
            else if (cthdbll.tongbanghi(txtMaHD.Text, cbMaMA.Text) == 0)
            {
                if (txtSoLuong.Text != "" && txtDonGia.Text != "")
                {
                    tinhtien();
                }
              

                cthdbll.insertCTHD(txtMaHD.Text, cbMaMA.Text, int.Parse(txtSoLuong.Text),int.Parse(txtDonGia.Text), int.Parse(txtThanhTien.Text));
               
                QL_Hoadon_Load_1(sender, e);
                txtSoLuong.Text = "";
                txtDonGia.Text = "";
                txtTongTien.Text = "0";
                cbMaMA.Text = "";


            }
            
            
           


        }
     
       public float TongTien(DataTable dt)
        {
            int sc = dgvCTHD.Rows.Count;
            float Tong = 0;
          
            for(int i = 0; i < sc - 1; i++)
            {
                Tong += float.Parse(dgvCTHD.Rows[i].Cells["ThanhTien"].Value.ToString());
            }
            return Tong;
        }

       

        private void btCTHD_Click(object sender, EventArgs e)
        {
            txtMaCTHD.Text = txtMaHD.Text.Trim();
            
            /////
            DataTable dt = cthdbll.Listcthd(txtMaCTHD.Text);
            dgvCTHD.DataSource = dt;
           
           
        }

        private void dgvHD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow = e.RowIndex;
            txtMaHD.Text = dgvHD.Rows[numrow].Cells[0].Value.ToString();
        //    dtpNgayBan.Text = dgvHD.Rows[numrow].Cells[1].Value.ToString();
            cbMaNV.Text = dgvHD.Rows[numrow].Cells[1].Value.ToString();
    //        txtTongTien.Text = dgvHD.Rows[numrow].Cells[2].Value.ToString();
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            txtMaHD.Text = "";
            cbMaNV.Text = "";
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void GR_Enter(object sender, EventArgs e)
        {

        }

        private void txtDonGia_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void dgvHD_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtThanhTien_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvCTHD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow = e.RowIndex;
            
            txtMaCTHD.Text = dgvCTHD.Rows[numrow].Cells[0].Value.ToString();
            cbMaMA.Text = dgvCTHD.Rows[numrow].Cells[1].Value.ToString();
            txtSoLuong.Text = dgvCTHD.Rows[numrow].Cells[2].Value.ToString();
            txtDonGia.Text = dgvCTHD.Rows[numrow].Cells[3].Value.ToString();
            txtThanhTien.Text = dgvCTHD.Rows[numrow].Cells[4].Value.ToString();
        }

        private void dgvCTHD_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btTinhTien_Click(object sender, EventArgs e)
        {
            DataTable dt = cthdbll.Listcthd(txtMaCTHD.Text);
            {
                dgvCTHD.DataSource = dt;

                if (dt.Rows.Count > 0)
                {
                    txtTongTien.Text = TongTien(dt).ToString();
                    //       hoadonbll.Themhd(txtMaHD.Text, cbMaNV.Text);
                    HoaDon_DTO hd = new HoaDon_DTO(txtMaHD.Text, cbMaNV.Text,Int32.Parse( txtTongTien.Text));
                    if (hoadonbll.editHD(hd))
                    {
                        MessageBox.Show("complete!");
                        dgvHD.DataSource = hoadonbll.getHD();
                    }
                    else
                    {
                        MessageBox.Show("failed");

                    }
                    //      NhanVien_DTO nhanvien = new NhanVien_DTO(txtMaNV.Text, txtTenNV.Text, txtGT.Text, txtDC.Text, txtSDT.Text, cbMaTK.Text);
                   
                }
                else
                {
                    txtTongTien.Text = "";
                }
            }
            
       //    txtMaHD.Text = "";
        }

        private void btXoaM_Click(object sender, EventArgs e)
        {
            /*
            if (MessageBox.Show("Bạn có muốn xóa phiếu xuất này không?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

               cthdbll.XoaCTHD(txtMaHD.Text,cbMaMA.Text, Int32.Parse(txtSoLuong.Text), Int32.Parse(txtDonGia.Text), Int32.Parse(txtThanhTien.Text));
            //    hoadonbll.Xoahd(txtMaHD.Text, cbMaNV.Text);
                MessageBox.Show("xoa thanh cong");
                QL_Hoadon_Load_1(sender, e);
            }
            */
            if (dgvCTHD.SelectedRows.Count > 0)
            {
                //      dgvCTHD.Rows.RemoveAt(dgvCTHD.SelectedRows[0].Index);
                cthdbll.XoaCTHD(txtMaHD.Text, cbMaMA.Text, Int32.Parse(txtSoLuong.Text), Int32.Parse(txtDonGia.Text), Int32.Parse(txtThanhTien.Text));
                MessageBox.Show("xoa thanh cong");
                QL_Hoadon_Load_1(sender, e);
            }

        }

       

            private void btTraM_Click(object sender, EventArgs e)
        {
            QL_Thucdon fthucdon = new QL_Thucdon();
            fthucdon.Show();
        }

        private void btInHD_Click(object sender, EventArgs e)
        {
            // Lấy thông tin thời gian ORDER
            DateTime orderTime = DateTime.Now;

            // Lấy danh sách các món ăn đã chọn từ DataGridView
            List<MonAn> selectedFoods = new List<MonAn>();
            foreach (DataGridViewRow row in dgvCTHD.Rows)
            {
                if (row.Cells["TenMA"].Value != null)
                {
                    //selectedFoods.Add(row.Cells["TenMA"].Value.ToString());
                    string tenMA = row.Cells["TenMA"].Value.ToString();
                    int soLuong = Convert.ToInt32(row.Cells["SoLuong"].Value);
                    int thanhTien = Convert.ToInt32(row.Cells["ThanhTien"].Value);

                    MonAn monAn = new MonAn(tenMA, soLuong, thanhTien);
                    selectedFoods.Add(monAn);
                }
            }

            // Tạo hóa đơn mới
            HoaDon newBill = new HoaDon(orderTime, selectedFoods);

            // In ra hóa đơn
            MessageBox.Show("Hóa đơn:\n" + newBill.ToString());
        }
       
        private void btok_Click(object sender, EventArgs e)
        {

            DeXuat_BLL dexuatBLL = new DeXuat_BLL();

            if (cbchoice.Text == "Món chay")
            {
                isVegetarian = true;
            }
            else { isVegetarian = false; }
            // txtThu.Text = cbchoice.Text;

            if (String.IsNullOrEmpty(txtcalo.Text) || !Int32.TryParse(txtcalo.Text, out targetCalories))
            {
                MessageBox.Show("Giá trị calo nhập vào là 1 số và không được bỏ trống!!!");
            }
            else
            {

                targetCalories = Int32.Parse(txtcalo.Text);
                //doạn ni để hiển thị kết quả lên viewmenu
                List<DTO.MenuItem> bestmenu = dexuatBLL.ok(targetCalories, isVegetarian);
                int bestPrice = dexuatBLL.GetBestPrice();
                if (bestmenu != null)
                {
                    viewMenu.DataSource = bestmenu;
                    string msg = "";
                    msg = msg + "Menu tốt nhất cho " + (isVegetarian ? " món chay" : " món mặn") + " với " + targetCalories + " calo" + " là: ";
                    lbTB.Text = msg;
                    txtTien.Text = "" + bestPrice;
                }
                else
                {
                    MessageBox.Show("Không có menu nào phù hợp với lượng calo của bạn, vui lòng nhập lại lượng calo khác!!!!!");
                }

            }

        }

        private void btorder_Click(object sender, EventArgs e)
        {
            // Lấy thông tin thời gian ORDER
            DateTime orderTime = DateTime.Now;

            // Lấy danh sách các món ăn đã chọn từ DataGridView
            List<MonAn> selectedFoods = new List<MonAn>();
            foreach (DataGridViewRow row in viewMenu.Rows)
            {
                if (row.Cells["TenMA"].Value != null)
                {
                    //selectedFoods.Add(row.Cells["TenMA"].Value.ToString());
                    string tenMA = row.Cells["TenMA"].Value.ToString();
                    int soLuong = 1;
                    int thanhTien = Convert.ToInt32(row.Cells["DonGia"].Value);

                    MonAn monAn = new MonAn(tenMA, soLuong, thanhTien);
                    selectedFoods.Add(monAn);
                }
            }

            // Tạo hóa đơn mới
            HoaDon newBill = new HoaDon(orderTime, selectedFoods);

            // In ra hóa đơn
            MessageBox.Show("                      HÓA ĐƠN:\n" + newBill.ToString());
        }
        public class MonAn
        {
            public string TenMA { get; set; }
            public int SoLuong { get; set; }
            //public double GiaTien { get; set; }
            public int ThanhTien { get; set; }

            public MonAn(string tenMA, int soLuong, int thanhTien)
            {
                TenMA = tenMA;
                SoLuong = soLuong;
                ThanhTien = thanhTien;
            }
        }
        public class HoaDon
        {
            public DateTime OrderTime { get; set; }
            public List<MonAn> SelectedFoods { get; set; }

            public HoaDon(DateTime orderTime, List<MonAn> selectedFoods)
            {
                OrderTime = orderTime;
                SelectedFoods = selectedFoods;
            }

            /*public override string ToString()
            {
                StringBuilder sb = new StringBuilder();

                // Thêm thông tin thời gian ORDER vào chuỗi đầu tiên
                sb.Append("Thời gian ORDER: ");
                sb.AppendLine(OrderTime.ToString());

                // Thêm danh sách các món ăn vào chuỗi
                sb.AppendLine("Danh sách các món ăn:");
                foreach (string food in SelectedFoods)
                {
                    sb.AppendFormat("{0} - Số lượng: {1}, Thành tiền: {2}\n", food.TenMA, food.SoLuong, food.ThanhTien);
                }

                return sb.ToString();
            }*/
            public override string ToString()
            {
                StringBuilder sb = new StringBuilder();

                // Thêm thông tin thời gian ORDER vào chuỗi đầu tiên
                sb.Append("Thời gian ORDER:      ");
                sb.AppendLine(OrderTime.ToString());

                // Kiểm tra danh sách các món ăn đã chọn có rỗng hay không
                if (SelectedFoods.Count == 0)
                {
                    sb.AppendLine("Không có món ăn nào được chọn.");
                }
                else
                {
                    /*// Tạo danh sách các đối tượng MonAn từ danh sách chuỗi SelectedFoods
                    List<MonAn> selectedMonAns = new List<MonAn>();
                    foreach (string food in SelectedFoods)
                    {
                        // Giả sử thông tin về số lượng và giá tiền của món ăn không có trong chuỗi được truyền vào,
                        // ta có thể truyền giá trị mặc định cho các thuộc tính này để tạo đối tượng MonAn.
                        MonAn monAn = new MonAn(food, SoLuong, thanhTien);
                        selectedMonAns.Add(monAn);
                    }

                    // Thêm danh sách các món ăn vào chuỗi
                    sb.AppendLine("Danh sách các món ăn:");
                    foreach (MonAn monAn in selectedMonAns)
                    {
                        sb.AppendFormat("{0}         Số lượng: {1},         Thành tiền: {2}\n", monAn.TenMA, monAn.SoLuong, monAn.ThanhTien);
                    }*/

                    // Thêm danh sách các món ăn vào chuỗi
                    sb.AppendLine("Danh sách các món ăn:");
                    sb.Append("Tên món                           số lượng            Thành tiền\n");
                    /*foreach (MonAn food in SelectedFoods)
                    {
                        sb.AppendFormat("{0}        {1}       {2}\n", food.TenMA, food.SoLuong, food.ThanhTien);
                    }*/

                    // Tính độ dài tối đa của các chuỗi TenMA
                    int maxLength = SelectedFoods.Max(x => x.TenMA.Length);

                    foreach (MonAn food in SelectedFoods)
                    {
                        sb.AppendFormat("{0,-20} {1,20} {2,30}\n", food.TenMA, food.SoLuong, food.ThanhTien);
                    }



                    int tongTien = SelectedFoods.Sum(food => food.ThanhTien);
                    sb.AppendFormat("Tổng tiền: {0}", tongTien);
                }

                return sb.ToString();
            }

        }

        private void btClearHD_Click(object sender, EventArgs e)
        {
            cbMaMA.Text = "";
            txtDonGia.Text = "";
            txtThanhTien.Text = "";
            txtSoLuong.Text = "";
            txtMaCTHD.Text = "";
            //dgvCTHD.Rows.Clear();
        }
    }
    
}
