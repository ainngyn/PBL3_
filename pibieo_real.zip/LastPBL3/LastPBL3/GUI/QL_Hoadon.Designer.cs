﻿namespace GUI
{
    partial class QL_Hoadon
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ABC = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btReset = new Guna.UI.WinForms.GunaButton();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btCTHD = new Guna.UI.WinForms.GunaButton();
            this.btInHD = new Guna.UI.WinForms.GunaButton();
            this.btHuyHD = new Guna.UI.WinForms.GunaButton();
            this.btThemHD = new Guna.UI.WinForms.GunaButton();
            this.GR = new System.Windows.Forms.GroupBox();
            this.btClearHD = new Guna.UI.WinForms.GunaButton();
            this.btTinhTien = new Guna.UI.WinForms.GunaButton();
            this.btXoaM = new Guna.UI.WinForms.GunaButton();
            this.btThemM = new Guna.UI.WinForms.GunaButton();
            this.dgvCTHD = new System.Windows.Forms.DataGridView();
            this.txtMaCTHD = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.cbMaMA = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbMaNV = new System.Windows.Forms.ComboBox();
            this.tblHoaDonBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pBL3DataSet6 = new GUI.PBL3DataSet6();
            this.dtpNgayBan = new System.Windows.Forms.DateTimePicker();
            this.txtMaHD = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvHD = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btok = new System.Windows.Forms.Button();
            this.btorder = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbTB = new System.Windows.Forms.Label();
            this.cbchoice = new System.Windows.Forms.ComboBox();
            this.viewMenu = new System.Windows.Forms.DataGridView();
            this.txtTien = new System.Windows.Forms.TextBox();
            this.txtcalo = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tblHoaDonTableAdapter = new GUI.PBL3DataSet6TableAdapters.tblHoaDonTableAdapter();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.ABC.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.GR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTHD)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblHoaDonBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHD)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // ABC
            // 
            this.ABC.Controls.Add(this.tabPage1);
            this.ABC.Controls.Add(this.tabPage2);
            this.ABC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ABC.Location = new System.Drawing.Point(0, 4);
            this.ABC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ABC.Name = "ABC";
            this.ABC.SelectedIndex = 0;
            this.ABC.Size = new System.Drawing.Size(1428, 756);
            this.ABC.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.btReset);
            this.tabPage1.Controls.Add(this.txtTongTien);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.btCTHD);
            this.tabPage1.Controls.Add(this.btInHD);
            this.tabPage1.Controls.Add(this.btHuyHD);
            this.tabPage1.Controls.Add(this.btThemHD);
            this.tabPage1.Controls.Add(this.GR);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 41);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1420, 711);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Hóa đơn";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // btReset
            // 
            this.btReset.AnimationHoverSpeed = 0.07F;
            this.btReset.AnimationSpeed = 0.03F;
            this.btReset.BaseColor = System.Drawing.Color.White;
            this.btReset.BorderColor = System.Drawing.Color.Black;
            this.btReset.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btReset.FocusedColor = System.Drawing.Color.Empty;
            this.btReset.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btReset.Image = global::GUI.Properties.Resources.Redo;
            this.btReset.ImageSize = new System.Drawing.Size(20, 20);
            this.btReset.Location = new System.Drawing.Point(467, 638);
            this.btReset.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btReset.Name = "btReset";
            this.btReset.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btReset.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btReset.OnHoverForeColor = System.Drawing.Color.White;
            this.btReset.OnHoverImage = null;
            this.btReset.OnPressedColor = System.Drawing.Color.Black;
            this.btReset.Size = new System.Drawing.Size(108, 41);
            this.btReset.TabIndex = 13;
            this.btReset.Text = "Reset";
            this.btReset.Click += new System.EventHandler(this.btReset_Click);
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(1122, 644);
            this.txtTongTien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(280, 39);
            this.txtTongTien.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(968, 644);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 32);
            this.label10.TabIndex = 6;
            this.label10.Text = "Tổng tiền";
            // 
            // btCTHD
            // 
            this.btCTHD.AnimationHoverSpeed = 0.07F;
            this.btCTHD.AnimationSpeed = 0.03F;
            this.btCTHD.BaseColor = System.Drawing.Color.White;
            this.btCTHD.BorderColor = System.Drawing.Color.Black;
            this.btCTHD.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btCTHD.FocusedColor = System.Drawing.Color.Empty;
            this.btCTHD.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCTHD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btCTHD.Image = global::GUI.Properties.Resources.Info;
            this.btCTHD.ImageSize = new System.Drawing.Size(20, 20);
            this.btCTHD.Location = new System.Drawing.Point(306, 638);
            this.btCTHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btCTHD.Name = "btCTHD";
            this.btCTHD.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btCTHD.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btCTHD.OnHoverForeColor = System.Drawing.Color.White;
            this.btCTHD.OnHoverImage = null;
            this.btCTHD.OnPressedColor = System.Drawing.Color.Black;
            this.btCTHD.Size = new System.Drawing.Size(134, 41);
            this.btCTHD.TabIndex = 5;
            this.btCTHD.Text = "Chi tiết HD";
            this.btCTHD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.btCTHD.Click += new System.EventHandler(this.btCTHD_Click);
            // 
            // btInHD
            // 
            this.btInHD.AnimationHoverSpeed = 0.07F;
            this.btInHD.AnimationSpeed = 0.03F;
            this.btInHD.BaseColor = System.Drawing.Color.White;
            this.btInHD.BorderColor = System.Drawing.Color.Black;
            this.btInHD.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btInHD.FocusedColor = System.Drawing.Color.Empty;
            this.btInHD.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btInHD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btInHD.Image = global::GUI.Properties.Resources.Exit;
            this.btInHD.ImageSize = new System.Drawing.Size(20, 20);
            this.btInHD.Location = new System.Drawing.Point(795, 644);
            this.btInHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btInHD.Name = "btInHD";
            this.btInHD.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btInHD.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btInHD.OnHoverForeColor = System.Drawing.Color.White;
            this.btInHD.OnHoverImage = null;
            this.btInHD.OnPressedColor = System.Drawing.Color.Black;
            this.btInHD.Size = new System.Drawing.Size(141, 41);
            this.btInHD.TabIndex = 4;
            this.btInHD.Text = "In hóa đơn";
            this.btInHD.Click += new System.EventHandler(this.btInHD_Click);
            // 
            // btHuyHD
            // 
            this.btHuyHD.AnimationHoverSpeed = 0.07F;
            this.btHuyHD.AnimationSpeed = 0.03F;
            this.btHuyHD.BaseColor = System.Drawing.Color.White;
            this.btHuyHD.BorderColor = System.Drawing.Color.Black;
            this.btHuyHD.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btHuyHD.FocusedColor = System.Drawing.Color.Empty;
            this.btHuyHD.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuyHD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btHuyHD.Image = global::GUI.Properties.Resources.Erase;
            this.btHuyHD.ImageSize = new System.Drawing.Size(20, 20);
            this.btHuyHD.Location = new System.Drawing.Point(169, 638);
            this.btHuyHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btHuyHD.Name = "btHuyHD";
            this.btHuyHD.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btHuyHD.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btHuyHD.OnHoverForeColor = System.Drawing.Color.White;
            this.btHuyHD.OnHoverImage = null;
            this.btHuyHD.OnPressedColor = System.Drawing.Color.Black;
            this.btHuyHD.Size = new System.Drawing.Size(105, 41);
            this.btHuyHD.TabIndex = 3;
            this.btHuyHD.Text = "Hủy";
            this.btHuyHD.Click += new System.EventHandler(this.btHuyHD_Click);
            // 
            // btThemHD
            // 
            this.btThemHD.AnimationHoverSpeed = 0.07F;
            this.btThemHD.AnimationSpeed = 0.03F;
            this.btThemHD.BaseColor = System.Drawing.Color.White;
            this.btThemHD.BorderColor = System.Drawing.Color.Black;
            this.btThemHD.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btThemHD.FocusedColor = System.Drawing.Color.Empty;
            this.btThemHD.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThemHD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btThemHD.Image = global::GUI.Properties.Resources.Create;
            this.btThemHD.ImageSize = new System.Drawing.Size(20, 20);
            this.btThemHD.Location = new System.Drawing.Point(28, 638);
            this.btThemHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btThemHD.Name = "btThemHD";
            this.btThemHD.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btThemHD.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btThemHD.OnHoverForeColor = System.Drawing.Color.White;
            this.btThemHD.OnHoverImage = null;
            this.btThemHD.OnPressedColor = System.Drawing.Color.Black;
            this.btThemHD.Size = new System.Drawing.Size(123, 41);
            this.btThemHD.TabIndex = 2;
            this.btThemHD.Text = "Thêm";
            this.btThemHD.Click += new System.EventHandler(this.btThemHD_Click);
            // 
            // GR
            // 
            this.GR.Controls.Add(this.btClearHD);
            this.GR.Controls.Add(this.btTinhTien);
            this.GR.Controls.Add(this.btXoaM);
            this.GR.Controls.Add(this.btThemM);
            this.GR.Controls.Add(this.dgvCTHD);
            this.GR.Controls.Add(this.txtMaCTHD);
            this.GR.Controls.Add(this.label4);
            this.GR.Controls.Add(this.txtSoLuong);
            this.GR.Controls.Add(this.txtThanhTien);
            this.GR.Controls.Add(this.txtDonGia);
            this.GR.Controls.Add(this.cbMaMA);
            this.GR.Controls.Add(this.label9);
            this.GR.Controls.Add(this.label8);
            this.GR.Controls.Add(this.label7);
            this.GR.Controls.Add(this.label6);
            this.GR.Location = new System.Drawing.Point(705, 8);
            this.GR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GR.Name = "GR";
            this.GR.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GR.Size = new System.Drawing.Size(696, 629);
            this.GR.TabIndex = 1;
            this.GR.TabStop = false;
            this.GR.Text = "Thông tin chi tiết hóa đơn";
            this.GR.Enter += new System.EventHandler(this.GR_Enter);
            // 
            // btClearHD
            // 
            this.btClearHD.AnimationHoverSpeed = 0.07F;
            this.btClearHD.AnimationSpeed = 0.03F;
            this.btClearHD.BaseColor = System.Drawing.Color.White;
            this.btClearHD.BorderColor = System.Drawing.Color.Black;
            this.btClearHD.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btClearHD.FocusedColor = System.Drawing.Color.Empty;
            this.btClearHD.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClearHD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btClearHD.Image = global::GUI.Properties.Resources.Redo;
            this.btClearHD.ImageSize = new System.Drawing.Size(20, 20);
            this.btClearHD.Location = new System.Drawing.Point(562, 222);
            this.btClearHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btClearHD.Name = "btClearHD";
            this.btClearHD.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btClearHD.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btClearHD.OnHoverForeColor = System.Drawing.Color.White;
            this.btClearHD.OnHoverImage = null;
            this.btClearHD.OnPressedColor = System.Drawing.Color.Black;
            this.btClearHD.Size = new System.Drawing.Size(108, 35);
            this.btClearHD.TabIndex = 14;
            this.btClearHD.Text = "Reset";
            this.btClearHD.Click += new System.EventHandler(this.btClearHD_Click);
            // 
            // btTinhTien
            // 
            this.btTinhTien.AnimationHoverSpeed = 0.07F;
            this.btTinhTien.AnimationSpeed = 0.03F;
            this.btTinhTien.BaseColor = System.Drawing.Color.White;
            this.btTinhTien.BorderColor = System.Drawing.Color.Black;
            this.btTinhTien.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btTinhTien.FocusedColor = System.Drawing.Color.Empty;
            this.btTinhTien.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTinhTien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btTinhTien.Image = global::GUI.Properties.Resources.Dollar;
            this.btTinhTien.ImageSize = new System.Drawing.Size(20, 20);
            this.btTinhTien.Location = new System.Drawing.Point(375, 222);
            this.btTinhTien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btTinhTien.Name = "btTinhTien";
            this.btTinhTien.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btTinhTien.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btTinhTien.OnHoverForeColor = System.Drawing.Color.White;
            this.btTinhTien.OnHoverImage = null;
            this.btTinhTien.OnPressedColor = System.Drawing.Color.Black;
            this.btTinhTien.Size = new System.Drawing.Size(145, 35);
            this.btTinhTien.TabIndex = 18;
            this.btTinhTien.Text = "Tính tiền";
            this.btTinhTien.Click += new System.EventHandler(this.btTinhTien_Click);
            // 
            // btXoaM
            // 
            this.btXoaM.AnimationHoverSpeed = 0.07F;
            this.btXoaM.AnimationSpeed = 0.03F;
            this.btXoaM.BaseColor = System.Drawing.Color.White;
            this.btXoaM.BorderColor = System.Drawing.Color.Black;
            this.btXoaM.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btXoaM.FocusedColor = System.Drawing.Color.Empty;
            this.btXoaM.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoaM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btXoaM.Image = global::GUI.Properties.Resources.Erase;
            this.btXoaM.ImageSize = new System.Drawing.Size(20, 20);
            this.btXoaM.Location = new System.Drawing.Point(222, 222);
            this.btXoaM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btXoaM.Name = "btXoaM";
            this.btXoaM.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btXoaM.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btXoaM.OnHoverForeColor = System.Drawing.Color.White;
            this.btXoaM.OnHoverImage = null;
            this.btXoaM.OnPressedColor = System.Drawing.Color.Black;
            this.btXoaM.Size = new System.Drawing.Size(134, 35);
            this.btXoaM.TabIndex = 17;
            this.btXoaM.Text = "Xóa món";
            this.btXoaM.Click += new System.EventHandler(this.btXoaM_Click);
            // 
            // btThemM
            // 
            this.btThemM.AnimationHoverSpeed = 0.07F;
            this.btThemM.AnimationSpeed = 0.03F;
            this.btThemM.BaseColor = System.Drawing.Color.White;
            this.btThemM.BorderColor = System.Drawing.Color.Black;
            this.btThemM.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btThemM.FocusedColor = System.Drawing.Color.Empty;
            this.btThemM.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThemM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btThemM.Image = global::GUI.Properties.Resources.Create;
            this.btThemM.ImageSize = new System.Drawing.Size(20, 20);
            this.btThemM.Location = new System.Drawing.Point(51, 222);
            this.btThemM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btThemM.Name = "btThemM";
            this.btThemM.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btThemM.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btThemM.OnHoverForeColor = System.Drawing.Color.White;
            this.btThemM.OnHoverImage = null;
            this.btThemM.OnPressedColor = System.Drawing.Color.Black;
            this.btThemM.Size = new System.Drawing.Size(147, 35);
            this.btThemM.TabIndex = 15;
            this.btThemM.Text = "Thêm món";
            this.btThemM.Click += new System.EventHandler(this.btThemM_Click);
            // 
            // dgvCTHD
            // 
            this.dgvCTHD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCTHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCTHD.Location = new System.Drawing.Point(14, 280);
            this.dgvCTHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvCTHD.Name = "dgvCTHD";
            this.dgvCTHD.RowHeadersWidth = 51;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCTHD.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCTHD.RowTemplate.Height = 24;
            this.dgvCTHD.Size = new System.Drawing.Size(657, 324);
            this.dgvCTHD.TabIndex = 14;
            this.dgvCTHD.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCTHD_CellClick);
            this.dgvCTHD.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCTHD_CellContentClick);
            // 
            // txtMaCTHD
            // 
            this.txtMaCTHD.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaCTHD.Location = new System.Drawing.Point(134, 44);
            this.txtMaCTHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMaCTHD.Name = "txtMaCTHD";
            this.txtMaCTHD.Size = new System.Drawing.Size(190, 35);
            this.txtMaCTHD.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(33, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 30);
            this.label4.TabIndex = 12;
            this.label4.Text = "Mã HD";
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuong.Location = new System.Drawing.Point(490, 100);
            this.txtSoLuong.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(180, 35);
            this.txtSoLuong.TabIndex = 11;
            this.txtSoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuong_KeyPress);
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThanhTien.Location = new System.Drawing.Point(490, 162);
            this.txtThanhTien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.Size = new System.Drawing.Size(180, 35);
            this.txtThanhTien.TabIndex = 10;
            this.txtThanhTien.TextChanged += new System.EventHandler(this.txtThanhTien_TextChanged);
            // 
            // txtDonGia
            // 
            this.txtDonGia.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonGia.Location = new System.Drawing.Point(490, 48);
            this.txtDonGia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(180, 35);
            this.txtDonGia.TabIndex = 9;
            this.txtDonGia.TextChanged += new System.EventHandler(this.txtDonGia_TextChanged);
            this.txtDonGia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDonGia_KeyPress);
            // 
            // cbMaMA
            // 
            this.cbMaMA.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMaMA.FormattingEnabled = true;
            this.cbMaMA.Location = new System.Drawing.Point(134, 135);
            this.cbMaMA.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbMaMA.Name = "cbMaMA";
            this.cbMaMA.Size = new System.Drawing.Size(190, 38);
            this.cbMaMA.TabIndex = 8;
            this.cbMaMA.SelectedIndexChanged += new System.EventHandler(this.cbMaMA_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(370, 166);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 30);
            this.label9.TabIndex = 5;
            this.label9.Text = "Thành tiền";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(370, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 30);
            this.label8.TabIndex = 4;
            this.label8.Text = "Đơn giá";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(370, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 30);
            this.label7.TabIndex = 3;
            this.label7.Text = "Số lượng";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(33, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 30);
            this.label6.TabIndex = 2;
            this.label6.Text = "Tên MA";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbMaNV);
            this.groupBox1.Controls.Add(this.dtpNgayBan);
            this.groupBox1.Controls.Add(this.txtMaHD);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dgvHD);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(19, 8);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(655, 604);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin chung";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // cbMaNV
            // 
            this.cbMaNV.DataSource = this.tblHoaDonBindingSource;
            this.cbMaNV.DisplayMember = "MaNV";
            this.cbMaNV.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMaNV.FormattingEnabled = true;
            this.cbMaNV.Location = new System.Drawing.Point(150, 162);
            this.cbMaNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbMaNV.Name = "cbMaNV";
            this.cbMaNV.Size = new System.Drawing.Size(312, 36);
            this.cbMaNV.TabIndex = 7;
            this.cbMaNV.ValueMember = "MaNV";
            // 
            // tblHoaDonBindingSource
            // 
            this.tblHoaDonBindingSource.DataMember = "tblHoaDon";
            this.tblHoaDonBindingSource.DataSource = this.pBL3DataSet6;
            // 
            // pBL3DataSet6
            // 
            this.pBL3DataSet6.DataSetName = "PBL3DataSet6";
            this.pBL3DataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dtpNgayBan
            // 
            this.dtpNgayBan.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayBan.Location = new System.Drawing.Point(150, 96);
            this.dtpNgayBan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpNgayBan.Name = "dtpNgayBan";
            this.dtpNgayBan.Size = new System.Drawing.Size(312, 35);
            this.dtpNgayBan.TabIndex = 6;
            // 
            // txtMaHD
            // 
            this.txtMaHD.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaHD.Location = new System.Drawing.Point(150, 35);
            this.txtMaHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMaHD.Name = "txtMaHD";
            this.txtMaHD.Size = new System.Drawing.Size(312, 35);
            this.txtMaHD.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 30);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mã NV";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 30);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ngày bán";
            // 
            // dgvHD
            // 
            this.dgvHD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHD.Location = new System.Drawing.Point(12, 226);
            this.dgvHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvHD.Name = "dgvHD";
            this.dgvHD.RowHeadersWidth = 51;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvHD.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvHD.RowTemplate.Height = 24;
            this.dgvHD.Size = new System.Drawing.Size(636, 370);
            this.dgvHD.TabIndex = 6;
            this.dgvHD.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHD_CellClick);
            this.dgvHD.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHD_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã HD";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.btok);
            this.tabPage2.Controls.Add(this.btorder);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 41);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(1420, 711);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Đề xuất";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GUI.Properties.Resources.bozodexuat1;
            this.pictureBox1.Location = new System.Drawing.Point(90, 134);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(363, 397);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // btok
            // 
            this.btok.Location = new System.Drawing.Point(749, 616);
            this.btok.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btok.Name = "btok";
            this.btok.Size = new System.Drawing.Size(114, 49);
            this.btok.TabIndex = 3;
            this.btok.Text = "OK";
            this.btok.UseVisualStyleBackColor = true;
            this.btok.Click += new System.EventHandler(this.btok_Click);
            // 
            // btorder
            // 
            this.btorder.Location = new System.Drawing.Point(1001, 616);
            this.btorder.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btorder.Name = "btorder";
            this.btorder.Size = new System.Drawing.Size(114, 49);
            this.btorder.TabIndex = 2;
            this.btorder.Text = "ORDER";
            this.btorder.UseVisualStyleBackColor = true;
            this.btorder.Click += new System.EventHandler(this.btorder_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(413, 31);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(294, 48);
            this.label11.TabIndex = 1;
            this.label11.Text = "MỜI BẠN CHỌN";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.groupBox2.Controls.Add(this.lbTB);
            this.groupBox2.Controls.Add(this.cbchoice);
            this.groupBox2.Controls.Add(this.viewMenu);
            this.groupBox2.Controls.Add(this.txtTien);
            this.groupBox2.Controls.Add(this.txtcalo);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(525, 96);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(794, 512);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // lbTB
            // 
            this.lbTB.AutoSize = true;
            this.lbTB.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTB.Location = new System.Drawing.Point(118, 160);
            this.lbTB.Name = "lbTB";
            this.lbTB.Size = new System.Drawing.Size(0, 30);
            this.lbTB.TabIndex = 9;
            // 
            // cbchoice
            // 
            this.cbchoice.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbchoice.FormattingEnabled = true;
            this.cbchoice.Items.AddRange(new object[] {
            "Món chay",
            "Món mặn"});
            this.cbchoice.Location = new System.Drawing.Point(260, 99);
            this.cbchoice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbchoice.Name = "cbchoice";
            this.cbchoice.Size = new System.Drawing.Size(306, 38);
            this.cbchoice.TabIndex = 8;
            // 
            // viewMenu
            // 
            this.viewMenu.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.viewMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.viewMenu.Location = new System.Drawing.Point(68, 195);
            this.viewMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.viewMenu.Name = "viewMenu";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.viewMenu.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.viewMenu.RowHeadersWidth = 51;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewMenu.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.viewMenu.RowTemplate.Height = 24;
            this.viewMenu.Size = new System.Drawing.Size(691, 202);
            this.viewMenu.TabIndex = 7;
            // 
            // txtTien
            // 
            this.txtTien.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTien.Location = new System.Drawing.Point(508, 436);
            this.txtTien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTien.Name = "txtTien";
            this.txtTien.Size = new System.Drawing.Size(249, 36);
            this.txtTien.TabIndex = 6;
            // 
            // txtcalo
            // 
            this.txtcalo.Location = new System.Drawing.Point(260, 34);
            this.txtcalo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtcalo.Name = "txtcalo";
            this.txtcalo.Size = new System.Drawing.Size(306, 39);
            this.txtcalo.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(367, 444);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(145, 32);
            this.label14.TabIndex = 4;
            this.label14.Text = "Tổng tiền : ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(33, 102);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(220, 32);
            this.label13.TabIndex = 3;
            this.label13.Text = "Chọn khẩu phần : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(225, 32);
            this.label12.TabIndex = 2;
            this.label12.Text = "Nhập lượng calo : ";
            // 
            // tblHoaDonTableAdapter
            // 
            this.tblHoaDonTableAdapter.ClearBeforeFill = true;
            // 
            // QL_Hoadon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.ABC);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "QL_Hoadon";
            this.Size = new System.Drawing.Size(1418, 749);
            this.Load += new System.EventHandler(this.QL_Hoadon_Load_1);
            this.ABC.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.GR.ResumeLayout(false);
            this.GR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTHD)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblHoaDonBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHD)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewMenu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl ABC;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox GR;
        private System.Windows.Forms.GroupBox groupBox1;
        private Guna.UI.WinForms.GunaButton btThemHD;
        private Guna.UI.WinForms.GunaButton btHuyHD;
        private Guna.UI.WinForms.GunaButton btCTHD;
        private Guna.UI.WinForms.GunaButton btInHD;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.ComboBox cbMaMA;
        private System.Windows.Forms.DataGridView dgvHD;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbMaNV;
        private System.Windows.Forms.DateTimePicker dtpNgayBan;
        private System.Windows.Forms.TextBox txtMaHD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.BindingSource tblHoaDonBindingSource;
        private PBL3DataSet6 pBL3DataSet6;
        private PBL3DataSet6TableAdapters.tblHoaDonTableAdapter tblHoaDonTableAdapter;
        private Guna.UI.WinForms.GunaButton btTinhTien;
        private Guna.UI.WinForms.GunaButton btXoaM;
        private Guna.UI.WinForms.GunaButton btThemM;
        private System.Windows.Forms.DataGridView dgvCTHD;
        private System.Windows.Forms.TextBox txtMaCTHD;
        private System.Windows.Forms.Label label4;
        private Guna.UI.WinForms.GunaButton btReset;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtcalo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label lbTB;
        private System.Windows.Forms.ComboBox cbchoice;
        private System.Windows.Forms.DataGridView viewMenu;
        private System.Windows.Forms.TextBox txtTien;
        private System.Windows.Forms.Button btok;
        private System.Windows.Forms.Button btorder;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI.WinForms.GunaButton btClearHD;
    }
}
