﻿namespace GUI
{
    partial class QL_Thongke
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbTKHD = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgThongKesp = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tsLamMoi = new Guna.UI.WinForms.GunaButton();
            this.tsThongKe = new Guna.UI.WinForms.GunaButton();
            this.cbKieuThongKe = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tbTKHD.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgThongKesp)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbTKHD);
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(3, 4);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1414, 745);
            this.tabControl1.TabIndex = 0;
            // 
            // tbTKHD
            // 
            this.tbTKHD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tbTKHD.Controls.Add(this.panel1);
            this.tbTKHD.Controls.Add(this.groupBox2);
            this.tbTKHD.Controls.Add(this.groupBox1);
            this.tbTKHD.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTKHD.Location = new System.Drawing.Point(4, 41);
            this.tbTKHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbTKHD.Name = "tbTKHD";
            this.tbTKHD.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbTKHD.Size = new System.Drawing.Size(1406, 700);
            this.tbTKHD.TabIndex = 0;
            this.tbTKHD.Text = "Thống kê số lượng";
            this.tbTKHD.Click += new System.EventHandler(this.tbTKHD_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(5, 8);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1394, 125);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(500, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(409, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thống Kê Số Lượng Bán";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgThongKesp);
            this.groupBox2.Location = new System.Drawing.Point(7, 348);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(1392, 342);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Danh sách";
            // 
            // dgThongKesp
            // 
            this.dgThongKesp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgThongKesp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgThongKesp.Location = new System.Drawing.Point(106, 42);
            this.dgThongKesp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgThongKesp.Name = "dgThongKesp";
            this.dgThongKesp.RowHeadersWidth = 51;
            this.dgThongKesp.RowTemplate.Height = 24;
            this.dgThongKesp.Size = new System.Drawing.Size(1180, 292);
            this.dgThongKesp.TabIndex = 0;
            this.dgThongKesp.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgThongKesp_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tsLamMoi);
            this.groupBox1.Controls.Add(this.tsThongKe);
            this.groupBox1.Controls.Add(this.cbKieuThongKe);
            this.groupBox1.Location = new System.Drawing.Point(7, 141);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(1392, 210);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thống kê";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // tsLamMoi
            // 
            this.tsLamMoi.AnimationHoverSpeed = 0.07F;
            this.tsLamMoi.AnimationSpeed = 0.03F;
            this.tsLamMoi.BaseColor = System.Drawing.Color.White;
            this.tsLamMoi.BorderColor = System.Drawing.Color.Black;
            this.tsLamMoi.DialogResult = System.Windows.Forms.DialogResult.None;
            this.tsLamMoi.FocusedColor = System.Drawing.Color.Empty;
            this.tsLamMoi.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsLamMoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tsLamMoi.Image = global::GUI.Properties.Resources.Redo;
            this.tsLamMoi.ImageSize = new System.Drawing.Size(20, 20);
            this.tsLamMoi.Location = new System.Drawing.Point(241, 54);
            this.tsLamMoi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tsLamMoi.Name = "tsLamMoi";
            this.tsLamMoi.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.tsLamMoi.OnHoverBorderColor = System.Drawing.Color.Black;
            this.tsLamMoi.OnHoverForeColor = System.Drawing.Color.White;
            this.tsLamMoi.OnHoverImage = null;
            this.tsLamMoi.OnPressedColor = System.Drawing.Color.Black;
            this.tsLamMoi.Size = new System.Drawing.Size(136, 42);
            this.tsLamMoi.TabIndex = 18;
            this.tsLamMoi.Text = "Reset";
            this.tsLamMoi.Click += new System.EventHandler(this.tsLamMoi_Click);
            // 
            // tsThongKe
            // 
            this.tsThongKe.AnimationHoverSpeed = 0.07F;
            this.tsThongKe.AnimationSpeed = 0.03F;
            this.tsThongKe.BaseColor = System.Drawing.Color.White;
            this.tsThongKe.BorderColor = System.Drawing.Color.Black;
            this.tsThongKe.DialogResult = System.Windows.Forms.DialogResult.None;
            this.tsThongKe.FocusedColor = System.Drawing.Color.Empty;
            this.tsThongKe.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsThongKe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tsThongKe.Image = global::GUI.Properties.Resources._3d_bar_chart;
            this.tsThongKe.ImageSize = new System.Drawing.Size(20, 20);
            this.tsThongKe.Location = new System.Drawing.Point(60, 54);
            this.tsThongKe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tsThongKe.Name = "tsThongKe";
            this.tsThongKe.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.tsThongKe.OnHoverBorderColor = System.Drawing.Color.Black;
            this.tsThongKe.OnHoverForeColor = System.Drawing.Color.White;
            this.tsThongKe.OnHoverImage = null;
            this.tsThongKe.OnPressedColor = System.Drawing.Color.Black;
            this.tsThongKe.Size = new System.Drawing.Size(145, 42);
            this.tsThongKe.TabIndex = 16;
            this.tsThongKe.Text = "Thống kê";
            this.tsThongKe.Click += new System.EventHandler(this.tsThongKe_Click);
            // 
            // cbKieuThongKe
            // 
            this.cbKieuThongKe.FormattingEnabled = true;
            this.cbKieuThongKe.Items.AddRange(new object[] {
            "Thống kê sản phẩm bán chạy",
            "Thống kê sản phẩm bán chậm"});
            this.cbKieuThongKe.Location = new System.Drawing.Point(60, 129);
            this.cbKieuThongKe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbKieuThongKe.Name = "cbKieuThongKe";
            this.cbKieuThongKe.Size = new System.Drawing.Size(416, 40);
            this.cbKieuThongKe.TabIndex = 0;
            this.cbKieuThongKe.Text = "Chọn kiểu thống kê";
            this.cbKieuThongKe.SelectedIndexChanged += new System.EventHandler(this.cbKieuThongKe_SelectedIndexChanged);
            // 
            // QL_Thongke
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "QL_Thongke";
            this.Size = new System.Drawing.Size(1418, 749);
            this.Load += new System.EventHandler(this.QL_Thongke_Load);
            this.tabControl1.ResumeLayout(false);
            this.tbTKHD.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgThongKesp)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbTKHD;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgThongKesp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbKieuThongKe;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaButton tsLamMoi;
        private Guna.UI.WinForms.GunaButton tsThongKe;
    }
}
