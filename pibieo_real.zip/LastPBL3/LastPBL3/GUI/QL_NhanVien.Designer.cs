﻿namespace GUI
{
    partial class QL_NhanVien
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbTenNV = new System.Windows.Forms.Label();
            this.lbMaNV = new System.Windows.Forms.Label();
            this.btReset = new Guna.UI.WinForms.GunaButton();
            this.btXoaNV = new Guna.UI.WinForms.GunaButton();
            this.btSuaNV = new Guna.UI.WinForms.GunaButton();
            this.btThemNV = new Guna.UI.WinForms.GunaButton();
            this.dgvNV = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.txtTenNV = new System.Windows.Forms.TextBox();
            this.txtDC = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbMaTK = new System.Windows.Forms.ComboBox();
            this.txtGT = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).BeginInit();
            this.SuspendLayout();
            // 
            // lbTenNV
            // 
            this.lbTenNV.AutoSize = true;
            this.lbTenNV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenNV.ForeColor = System.Drawing.Color.Black;
            this.lbTenNV.Location = new System.Drawing.Point(944, 150);
            this.lbTenNV.Name = "lbTenNV";
            this.lbTenNV.Size = new System.Drawing.Size(156, 26);
            this.lbTenNV.TabIndex = 14;
            this.lbTenNV.Text = "Tên nhân viên";
            // 
            // lbMaNV
            // 
            this.lbMaNV.AutoSize = true;
            this.lbMaNV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaNV.ForeColor = System.Drawing.Color.Black;
            this.lbMaNV.Location = new System.Drawing.Point(944, 88);
            this.lbMaNV.Name = "lbMaNV";
            this.lbMaNV.Size = new System.Drawing.Size(152, 26);
            this.lbMaNV.TabIndex = 13;
            this.lbMaNV.Text = "Mã nhân viên";
            // 
            // btReset
            // 
            this.btReset.AnimationHoverSpeed = 0.07F;
            this.btReset.AnimationSpeed = 0.03F;
            this.btReset.BaseColor = System.Drawing.Color.White;
            this.btReset.BorderColor = System.Drawing.Color.Black;
            this.btReset.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btReset.FocusedColor = System.Drawing.Color.Empty;
            this.btReset.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btReset.Image = global::GUI.Properties.Resources.Redo;
            this.btReset.ImageSize = new System.Drawing.Size(20, 20);
            this.btReset.Location = new System.Drawing.Point(1215, 664);
            this.btReset.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btReset.Name = "btReset";
            this.btReset.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btReset.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btReset.OnHoverForeColor = System.Drawing.Color.White;
            this.btReset.OnHoverImage = null;
            this.btReset.OnPressedColor = System.Drawing.Color.Black;
            this.btReset.Size = new System.Drawing.Size(100, 42);
            this.btReset.TabIndex = 12;
            this.btReset.Text = "Reset";
            this.btReset.Click += new System.EventHandler(this.btReset_Click);
            // 
            // btXoaNV
            // 
            this.btXoaNV.AnimationHoverSpeed = 0.07F;
            this.btXoaNV.AnimationSpeed = 0.03F;
            this.btXoaNV.BaseColor = System.Drawing.Color.White;
            this.btXoaNV.BorderColor = System.Drawing.Color.Black;
            this.btXoaNV.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btXoaNV.FocusedColor = System.Drawing.Color.Empty;
            this.btXoaNV.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoaNV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btXoaNV.Image = global::GUI.Properties.Resources.Erase;
            this.btXoaNV.ImageSize = new System.Drawing.Size(20, 20);
            this.btXoaNV.Location = new System.Drawing.Point(1069, 664);
            this.btXoaNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btXoaNV.Name = "btXoaNV";
            this.btXoaNV.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btXoaNV.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btXoaNV.OnHoverForeColor = System.Drawing.Color.White;
            this.btXoaNV.OnHoverImage = null;
            this.btXoaNV.OnPressedColor = System.Drawing.Color.Black;
            this.btXoaNV.Size = new System.Drawing.Size(100, 42);
            this.btXoaNV.TabIndex = 11;
            this.btXoaNV.Text = "Xóa";
            this.btXoaNV.Click += new System.EventHandler(this.btXoaNV_Click);
            // 
            // btSuaNV
            // 
            this.btSuaNV.AnimationHoverSpeed = 0.07F;
            this.btSuaNV.AnimationSpeed = 0.03F;
            this.btSuaNV.BaseColor = System.Drawing.Color.White;
            this.btSuaNV.BorderColor = System.Drawing.Color.Black;
            this.btSuaNV.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btSuaNV.FocusedColor = System.Drawing.Color.Empty;
            this.btSuaNV.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSuaNV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btSuaNV.Image = global::GUI.Properties.Resources.Modify;
            this.btSuaNV.ImageSize = new System.Drawing.Size(20, 20);
            this.btSuaNV.Location = new System.Drawing.Point(934, 664);
            this.btSuaNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btSuaNV.Name = "btSuaNV";
            this.btSuaNV.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btSuaNV.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btSuaNV.OnHoverForeColor = System.Drawing.Color.White;
            this.btSuaNV.OnHoverImage = null;
            this.btSuaNV.OnPressedColor = System.Drawing.Color.Black;
            this.btSuaNV.Size = new System.Drawing.Size(101, 42);
            this.btSuaNV.TabIndex = 10;
            this.btSuaNV.Text = "Sửa";
            this.btSuaNV.Click += new System.EventHandler(this.btSuaNV_Click_1);
            // 
            // btThemNV
            // 
            this.btThemNV.AnimationHoverSpeed = 0.07F;
            this.btThemNV.AnimationSpeed = 0.03F;
            this.btThemNV.BaseColor = System.Drawing.Color.White;
            this.btThemNV.BorderColor = System.Drawing.Color.Black;
            this.btThemNV.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btThemNV.FocusedColor = System.Drawing.Color.Empty;
            this.btThemNV.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThemNV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btThemNV.Image = global::GUI.Properties.Resources.Create;
            this.btThemNV.ImageSize = new System.Drawing.Size(20, 20);
            this.btThemNV.Location = new System.Drawing.Point(798, 664);
            this.btThemNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btThemNV.Name = "btThemNV";
            this.btThemNV.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btThemNV.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btThemNV.OnHoverForeColor = System.Drawing.Color.White;
            this.btThemNV.OnHoverImage = null;
            this.btThemNV.OnPressedColor = System.Drawing.Color.Black;
            this.btThemNV.Size = new System.Drawing.Size(106, 42);
            this.btThemNV.TabIndex = 9;
            this.btThemNV.Text = "Thêm";
            this.btThemNV.Click += new System.EventHandler(this.btThemNV_Click_1);
            // 
            // dgvNV
            // 
            this.dgvNV.AllowUserToOrderColumns = true;
            this.dgvNV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNV.BackgroundColor = System.Drawing.Color.Silver;
            this.dgvNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNV.Location = new System.Drawing.Point(16, 52);
            this.dgvNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvNV.Name = "dgvNV";
            this.dgvNV.RowHeadersWidth = 51;
            this.dgvNV.RowTemplate.Height = 24;
            this.dgvNV.Size = new System.Drawing.Size(900, 586);
            this.dgvNV.TabIndex = 8;
            this.dgvNV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNV_CellClick);
            this.dgvNV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNV_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(944, 224);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 26);
            this.label1.TabIndex = 15;
            this.label1.Text = "Giới tính";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(944, 301);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 26);
            this.label3.TabIndex = 17;
            this.label3.Text = "Địa chỉ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(944, 381);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 26);
            this.label4.TabIndex = 18;
            this.label4.Text = "Số điện thoại";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtMaNV
            // 
            this.txtMaNV.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaNV.Location = new System.Drawing.Point(1100, 78);
            this.txtMaNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(250, 37);
            this.txtMaNV.TabIndex = 19;
            // 
            // txtTenNV
            // 
            this.txtTenNV.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenNV.Location = new System.Drawing.Point(1100, 140);
            this.txtTenNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTenNV.Name = "txtTenNV";
            this.txtTenNV.Size = new System.Drawing.Size(250, 37);
            this.txtTenNV.TabIndex = 20;
            // 
            // txtDC
            // 
            this.txtDC.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDC.Location = new System.Drawing.Point(1100, 291);
            this.txtDC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDC.Name = "txtDC";
            this.txtDC.Size = new System.Drawing.Size(250, 37);
            this.txtDC.TabIndex = 23;
            // 
            // txtSDT
            // 
            this.txtSDT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT.Location = new System.Drawing.Point(1100, 368);
            this.txtSDT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(250, 37);
            this.txtSDT.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(945, 454);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 26);
            this.label5.TabIndex = 25;
            this.label5.Text = "Mã Tk";
            // 
            // cbMaTK
            // 
            this.cbMaTK.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMaTK.FormattingEnabled = true;
            this.cbMaTK.Location = new System.Drawing.Point(1100, 444);
            this.cbMaTK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbMaTK.Name = "cbMaTK";
            this.cbMaTK.Size = new System.Drawing.Size(250, 38);
            this.cbMaTK.TabIndex = 26;
            this.cbMaTK.SelectedIndexChanged += new System.EventHandler(this.cbMaTK_SelectedIndexChanged);
            // 
            // txtGT
            // 
            this.txtGT.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGT.FormattingEnabled = true;
            this.txtGT.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.txtGT.Location = new System.Drawing.Point(1100, 216);
            this.txtGT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtGT.Name = "txtGT";
            this.txtGT.Size = new System.Drawing.Size(250, 38);
            this.txtGT.TabIndex = 27;
            // 
            // QL_NhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.txtGT);
            this.Controls.Add(this.cbMaTK);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSDT);
            this.Controls.Add(this.txtDC);
            this.Controls.Add(this.txtTenNV);
            this.Controls.Add(this.txtMaNV);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbTenNV);
            this.Controls.Add(this.lbMaNV);
            this.Controls.Add(this.btReset);
            this.Controls.Add(this.btXoaNV);
            this.Controls.Add(this.btSuaNV);
            this.Controls.Add(this.btThemNV);
            this.Controls.Add(this.dgvNV);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "QL_NhanVien";
            this.Size = new System.Drawing.Size(1414, 745);
            this.Load += new System.EventHandler(this.QL_NhanVien_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbTenNV;
        private System.Windows.Forms.Label lbMaNV;
        private Guna.UI.WinForms.GunaButton btReset;
        private Guna.UI.WinForms.GunaButton btXoaNV;
        private Guna.UI.WinForms.GunaButton btSuaNV;
        private Guna.UI.WinForms.GunaButton btThemNV;
        private System.Windows.Forms.DataGridView dgvNV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.TextBox txtTenNV;
        private System.Windows.Forms.TextBox txtDC;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbMaTK;
        private System.Windows.Forms.ComboBox txtGT;
    }
}
