﻿using BLL;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace GUI
{
    public partial class frmDangnhap : Form
    {
        TaiKhoan_DTO taikhoan = new TaiKhoan_DTO();
        TaiKhoan_BLL TKBLL = new TaiKhoan_BLL();

    
       
        public frmDangnhap()
        {
            InitializeComponent();
        }

        private void frmDangnhap_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            taikhoan.TaiKhoan = txtTaikhoan.Text;
            taikhoan.MatKhau = txtMatkhau.Text;
            txtMatkhau.PasswordChar = '*';

            string getuser = TKBLL.CheckLogic(taikhoan);
            switch (getuser)
            {
                case "requeid_taikhoan":
                    MessageBox.Show("Tài khoản không được để trống");
                    return;

                case "requeid_password":
                    MessageBox.Show("Mật khẩu không được để trống");
                    return;

                case "Tài khoản hoặc mật khẩu không chính xác":
                    MessageBox.Show("Tài khoản hoặc mật khẩu không chính xác!");
                    return;
            }

            MessageBox.Show("Xin chúc mừng bạn đã đăng nhập thành công hệ thống!");


            frmMain main = new frmMain();
            main.Sender(txtTaikhoan.Text);
            main.Show();
            this.Hide();
        }
       
        private void txtTaikhoan_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
