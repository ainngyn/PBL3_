﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class NhanVien_DTO
    {
        public string MaNV { get; set; }
        public string TenNV { get; set; }
        public string GioiTinh { get; set; }
        public string DiaChi { get; set; }
        public string DienThoai { get; set; }
        public string FK_MaTK { get; set; }
        public NhanVien_DTO()
        {
            this.MaNV = "";
            this.TenNV = "";
            this.GioiTinh = "";
            this.DiaChi = "";
            this.DienThoai = "";
            this.FK_MaTK = "";

        }


        public NhanVien_DTO(string manv, string tennv, string gioitinh,string diachi,string dienthoai,string fk_matk)
        {
            this.MaNV = manv;
            this.TenNV = tennv;
            this.GioiTinh = gioitinh;
            this.DiaChi = diachi;
            this.DienThoai = dienthoai;
            this.FK_MaTK = fk_matk;
        }


    }
}
