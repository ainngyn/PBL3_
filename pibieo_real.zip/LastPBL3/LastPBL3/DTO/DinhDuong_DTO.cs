﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DinhDuong_DTO
    {
        public string MaDD { get; set; }
        public string TenDD { get; set; }
        public DinhDuong_DTO() {
            this.MaDD = "";
            this.TenDD = "";
        }
        public DinhDuong_DTO(string madd,string tendd)
        {
            this.MaDD = madd;
            this.TenDD = tendd;
        }
    }
}
