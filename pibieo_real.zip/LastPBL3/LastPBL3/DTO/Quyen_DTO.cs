﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
     public class Quyen_DTO
    {
        public int MaQuyen;
        public string TenQuyen;
        public int maquyen
        {
            get { return MaQuyen; }
            set { MaQuyen = value; }
        }
        public string tenquyen
        {
            get { return TenQuyen; }
            set { TenQuyen = value; }   
        }
        public Quyen_DTO()
        {
            maquyen = 1;
            tenquyen = "";

        }
        public Quyen_DTO(int maquyen, string tenquyen)
        {
            this.maquyen = maquyen;
            this.tenquyen = tenquyen;
        }
    }
}
