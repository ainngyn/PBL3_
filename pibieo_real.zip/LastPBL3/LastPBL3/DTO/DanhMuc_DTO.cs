﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DanhMuc_DTO
    {
        public string MaDM { get; set; }
        public string TenDM { get; set; }
        public DanhMuc_DTO() {
            this.MaDM = "";
            this.TenDM = "";
        }
        public DanhMuc_DTO(string madm, string tendm)
        {
            this.MaDM = madm;
            this.TenDM = tendm;
        }
    }

}
